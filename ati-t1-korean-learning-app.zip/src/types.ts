export type Level = 'Beginner' | 'Intermediate' | 'Advanced';

export interface UserProgress {
  userId: string;
  level: Level;
  xp: number;
  streak: number;
  lastActive: string;
  completedLessons: string[];
  currentGoal: string;
}

export interface Lesson {
  id: string;
  unitId: string;
  title: string;
  description: string;
  type: 'vocabulary' | 'grammar' | 'conversation';
  vocabulary?: {
    word: string;
    meaning: string;
    example: string;
    audio?: string;
  }[];
  grammar?: {
    rule: string;
    explanation: string;
    examples: string[];
  };
  quiz: QuizQuestion[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  type: 'multiple-choice' | 'reorder' | 'fill-blank';
}

export interface Flashcard {
  id: string;
  front: string;
  back: string;
  nextReview: string;
  interval: number;
}
