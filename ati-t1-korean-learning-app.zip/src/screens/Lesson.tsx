import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_LESSONS } from '../data/lessons';
import { UserProgress } from '../types';
import { X, Check, ArrowRight, Volume2, Trophy } from 'lucide-react';
import { cn } from '../lib/utils';

interface Props {
  progress: UserProgress;
  setProgress: (p: UserProgress) => void;
}

export default function LessonScreen({ progress, setProgress }: Props) {
  const { id } = useParams();
  const navigate = useNavigate();
  const lesson = MOCK_LESSONS.find(l => l.id === id);

  const [step, setStep] = useState(0); // 0: Vocab, 1: Quiz
  const [vocabIdx, setVocabIdx] = useState(0);
  const [quizIdx, setQuizIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [showResult, setShowResult] = useState(false);

  if (!lesson) return <div>Lesson not found</div>;

  const totalSteps = (lesson.vocabulary?.length || 0) + (lesson.quiz?.length || 0);
  const currentProgress = ((step === 0 ? vocabIdx : (lesson.vocabulary?.length || 0) + quizIdx) / totalSteps) * 100;

  const handleNextVocab = () => {
    if (vocabIdx < (lesson.vocabulary?.length || 0) - 1) {
      setVocabIdx(v => v + 1);
    } else {
      setStep(1);
    }
  };

  const handleCheckAnswer = () => {
    const question = lesson.quiz[quizIdx];
    const correct = selectedAnswer === question.correctAnswer;
    setIsCorrect(correct);
  };

  const handleNextQuiz = () => {
    if (quizIdx < lesson.quiz.length - 1) {
      setQuizIdx(q => q + 1);
      setSelectedAnswer(null);
      setIsCorrect(null);
    } else {
      setShowResult(true);
      // Update progress
      const newProgress = {
        ...progress,
        xp: progress.xp + 20,
        completedLessons: [...new Set([...progress.completedLessons, lesson.id])]
      };
      setProgress(newProgress);
      localStorage.setItem('ati_t1_progress', JSON.stringify(newProgress));
    }
  };

  if (showResult) {
    return (
      <div className="flex flex-col items-center justify-center h-full p-6 text-center bg-natural-bg">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="w-32 h-32 bg-natural-terracotta rounded-full flex items-center justify-center mb-6 shadow-xl"
        >
          <Trophy size={64} className="text-white" />
        </motion.div>
        <h2 className="text-3xl font-black text-natural-ink mb-2">Hoàn thành bài học!</h2>
        <p className="text-natural-muted font-bold mb-8">Bạn nhận được +20 XP 💎</p>
        <button
          onClick={() => navigate('/')}
          className="bg-natural-sage text-white px-10 py-4 rounded-2xl font-black text-lg shadow-lg hover:bg-natural-sage-dark transition-all"
        >
          Trở về trang chủ
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto h-full flex flex-col p-8">
      {/* Header */}
      <div className="flex items-center gap-6 mb-12">
        <button onClick={() => navigate('/')} className="text-natural-muted hover:text-natural-ink transition-colors">
          <X size={28} />
        </button>
        <div className="flex-1 h-4 bg-natural-line rounded-full overflow-hidden shadow-inner">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${currentProgress}%` }}
            className="h-full bg-natural-sage shadow-[0_0_10px_rgba(138,154,91,0.5)]"
          />
        </div>
      </div>

      <div className="flex-1 flex flex-col justify-center">
        <AnimatePresence mode="wait">
          {step === 0 ? (
            <motion.div
              key={`vocab-${vocabIdx}`}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-10 text-center"
            >
              <div className="text-9xl font-black text-natural-sage mb-4 drop-shadow-sm">{lesson.vocabulary?.[vocabIdx].word}</div>
              <div className="text-4xl text-natural-ink font-bold">{lesson.vocabulary?.[vocabIdx].meaning}</div>
              <div className="p-8 bg-white rounded-3xl border-2 border-natural-line shadow-sm">
                <p className="text-natural-muted font-bold uppercase text-xs tracking-widest mb-2">Ví dụ:</p>
                <p className="text-2xl font-bold text-natural-ink italic">"{lesson.vocabulary?.[vocabIdx].example}"</p>
              </div>
              <button className="p-5 bg-natural-beige text-natural-sage rounded-full hover:bg-natural-line transition-all shadow-sm">
                <Volume2 size={40} />
              </button>
            </motion.div>
          ) : (
            <motion.div
              key={`quiz-${quizIdx}`}
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-10"
            >
              <h3 className="text-3xl font-black text-center mb-12 text-natural-ink">{lesson.quiz[quizIdx].question}</h3>
              <div className="grid gap-5">
                {lesson.quiz[quizIdx].options.map((option) => (
                  <button
                    key={option}
                    onClick={() => isCorrect === null && setSelectedAnswer(option)}
                    className={cn(
                      "p-6 rounded-2xl border-2 text-left text-xl font-bold transition-all shadow-sm",
                      selectedAnswer === option ? "border-natural-sage bg-natural-beige text-natural-sage" : "border-natural-line bg-white hover:border-natural-muted",
                      isCorrect !== null && option === lesson.quiz[quizIdx].correctAnswer && "border-emerald-500 bg-emerald-50 text-emerald-700",
                      isCorrect === false && selectedAnswer === option && "border-rose-500 bg-rose-50 text-rose-700"
                    )}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer Actions */}
      <div className="py-10 border-t border-natural-line">
        {step === 0 ? (
          <button
            onClick={handleNextVocab}
            className="w-full bg-natural-sage text-white py-5 rounded-2xl font-black text-xl flex items-center justify-center gap-3 shadow-lg hover:bg-natural-sage-dark transition-all"
          >
            Tiếp tục <ArrowRight size={24} />
          </button>
        ) : (
          <div className="space-y-4">
            {isCorrect === null ? (
              <button
                disabled={!selectedAnswer}
                onClick={handleCheckAnswer}
                className="w-full bg-natural-sage text-white py-5 rounded-2xl font-black text-xl disabled:opacity-50 shadow-lg"
              >
                Kiểm tra đáp án
              </button>
            ) : (
              <div className={cn(
                "p-8 rounded-3xl flex items-center justify-between shadow-xl",
                isCorrect ? "bg-emerald-500 text-white" : "bg-rose-500 text-white"
              )}>
                <div className="flex items-center gap-4">
                  <div className="p-3 bg-white/20 rounded-full">
                    {isCorrect ? <Check size={32} /> : <X size={32} />}
                  </div>
                  <div>
                    <p className="font-black text-2xl">{isCorrect ? 'Tuyệt vời!' : 'Đáp án đúng:'}</p>
                    {!isCorrect && <p className="font-bold text-lg opacity-90">{lesson.quiz[quizIdx].correctAnswer}</p>}
                  </div>
                </div>
                <button
                  onClick={handleNextQuiz}
                  className="bg-white text-natural-ink px-8 py-4 rounded-xl font-black shadow-lg hover:scale-105 transition-transform"
                >
                  Tiếp tục
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
