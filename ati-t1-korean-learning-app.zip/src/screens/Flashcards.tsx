import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { RotateCcw, Check, X, CreditCard, Sparkles } from 'lucide-react';
import { cn } from '../lib/utils';

interface Flashcard {
  id: string;
  front: string;
  back: string;
  example?: string;
}

const MOCK_CARDS: Flashcard[] = [
  { id: '1', front: '안녕하세요', back: 'Hello', example: '안녕하세요, 제 이름은 민수입니다.' },
  { id: '2', front: '감사합니다', back: 'Thank you', example: '도와주셔서 감사합니다.' },
  { id: '3', front: '학교', back: 'School', example: '저는 학교에 갑니다.' },
  { id: '4', front: '물', back: 'Water', example: '물 좀 주세요.' },
];

export default function FlashcardsScreen() {
  const [cards, setCards] = useState(MOCK_CARDS);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [direction, setDirection] = useState(0);

  const card = cards[currentIdx];

  const handleNext = (known: boolean) => {
    setDirection(known ? 1 : -1);
    setTimeout(() => {
      setIsFlipped(false);
      setCurrentIdx((prev) => (prev + 1) % cards.length);
      setDirection(0);
    }, 300);
  };

  return (
    <div className="max-w-2xl mx-auto h-full flex flex-col p-6">
      <header className="mb-12 text-center">
        <h2 className="text-3xl font-bold mb-2">Daily Review</h2>
        <p className="text-slate-500">Master your vocabulary with Spaced Repetition</p>
        <div className="flex justify-center gap-2 mt-4">
          {cards.map((_, i) => (
            <div
              key={i}
              className={cn(
                "h-1.5 rounded-full transition-all duration-300",
                i === currentIdx ? "w-8 bg-natural-sage" : "w-2 bg-natural-line"
              )}
            />
          ))}
        </div>
      </header>

      <div className="flex-1 flex flex-col items-center justify-center">
        <div className="relative w-full max-w-sm aspect-[3/4] perspective-1000">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIdx}
              initial={{ x: direction * 100, opacity: 0, rotateY: 0 }}
              animate={{ x: 0, opacity: 1, rotateY: isFlipped ? 180 : 0 }}
              exit={{ x: -direction * 100, opacity: 0 }}
              transition={{ duration: 0.4, type: 'spring', stiffness: 260, damping: 20 }}
              onClick={() => setIsFlipped(!isFlipped)}
              className="w-full h-full relative cursor-pointer preserve-3d"
            >
              {/* Front */}
              <div className={cn(
                "absolute inset-0 bg-white rounded-[2.5rem] shadow-2xl border-2 border-natural-line flex flex-col items-center justify-center p-8 backface-hidden",
                isFlipped && "hidden"
              )}>
                <div className="absolute top-8 left-8 text-natural-sage">
                  <Sparkles size={24} />
                </div>
                <div className="text-6xl font-bold text-natural-ink text-center">{card.front}</div>
                <p className="mt-8 text-natural-muted font-medium">Tap to flip</p>
              </div>

              {/* Back */}
              <div className={cn(
                "absolute inset-0 bg-natural-sage rounded-[2.5rem] shadow-2xl flex flex-col items-center justify-center p-8 backface-hidden [transform:rotateY(180deg)] text-white",
                !isFlipped && "hidden"
              )}>
                <div className="text-4xl font-bold mb-4">{card.back}</div>
                {card.example && (
                  <div className="bg-white/10 p-4 rounded-2xl text-center max-w-xs">
                    <p className="text-sm opacity-80 mb-1 italic">Example:</p>
                    <p className="text-lg font-medium">{card.example}</p>
                  </div>
                )}
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      <div className="py-12 flex justify-center gap-6">
        <button
          onClick={() => handleNext(false)}
          className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center hover:bg-rose-100 transition-all shadow-lg border border-rose-100"
        >
          <X size={32} />
        </button>
        <button
          onClick={() => setIsFlipped(!isFlipped)}
          className="w-16 h-16 rounded-full bg-slate-100 text-slate-600 flex items-center justify-center hover:bg-slate-200 transition-all shadow-lg"
        >
          <RotateCcw size={28} />
        </button>
        <button
          onClick={() => handleNext(true)}
          className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center hover:bg-emerald-100 transition-all shadow-lg border border-emerald-100"
        >
          <Check size={32} />
        </button>
      </div>
    </div>
  );
}
