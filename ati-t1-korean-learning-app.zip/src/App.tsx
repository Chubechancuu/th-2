/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { Home, BookOpen, MessageSquare, CreditCard, User, Settings, Flame, Trophy, Star } from 'lucide-react';
import { cn } from './lib/utils';
import { UserProgress, Level } from './types';

// Screens (to be implemented)
import HomeScreen from './screens/Home';
import LessonScreen from './screens/Lesson';
import AIChatScreen from './screens/AIChat';
import FlashcardsScreen from './screens/Flashcards';
import ProfileScreen from './screens/Profile';
import OnboardingScreen from './screens/Onboarding';

export default function App() {
  const [userProgress, setUserProgress] = useState<UserProgress | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);

  useEffect(() => {
    // Simulate auth check and load progress from localStorage
    const savedProgress = localStorage.getItem('ati_t1_progress');
    if (savedProgress) {
      setUserProgress(JSON.parse(savedProgress));
    }
    setIsAuthReady(true);
  }, []);

  const handleOnboardingComplete = (level: Level, goal: string) => {
    const newProgress: UserProgress = {
      userId: 'guest',
      level,
      xp: 0,
      streak: 1,
      lastActive: new Date().toISOString(),
      completedLessons: [],
      currentGoal: goal,
    };
    setUserProgress(newProgress);
    localStorage.setItem('ati_t1_progress', JSON.stringify(newProgress));
  };

  if (!isAuthReady) return null;

  if (!userProgress) {
    return <OnboardingScreen onComplete={handleOnboardingComplete} />;
  }

  return (
    <Router>
      <div className="flex flex-col h-screen bg-natural-bg text-natural-ink font-sans overflow-hidden">
        {/* Header */}
        <header className="bg-white px-10 py-4 flex justify-between items-center border-b-2 border-natural-line z-10">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-natural-sage rounded-lg flex items-center justify-center text-white font-bold text-xl">
              K
            </div>
            <h1 className="text-2xl font-extrabold tracking-tight text-[#4A5D4E]">ATI T1 KOREAN</h1>
          </div>
          <div className="flex gap-6 items-center">
            <div className="flex items-center gap-1.5 font-semibold text-lg">
              <span className="text-xl">🔥</span> {userProgress.streak}
            </div>
            <div className="flex items-center gap-1.5 font-semibold text-lg">
              <span className="text-xl">💎</span> {userProgress.xp.toLocaleString()}
            </div>
            <div className="flex items-center gap-1.5 font-semibold text-lg">
              <span className="text-xl">❤️</span> 5
            </div>
          </div>
        </header>

        {/* Main Layout */}
        <div className="flex-1 grid grid-cols-[260px_1fr_280px] gap-[2px] bg-natural-line overflow-hidden">
          {/* Sidebar Left */}
          <aside className="bg-white p-8 flex flex-col h-full overflow-y-auto">
            <div className="section-title">Danh mục học</div>
            <div className="space-y-2 flex-1">
              <NavItem to="/" icon="🏠" label="Trang chủ" />
              <NavItem to="/ai-chat" icon="🗣️" label="Hội thoại AI" />
              <NavItem to="/flashcards" icon="🗂️" label="Flashcards" />
              <NavItem to="/profile" icon="🏆" label="Bảng xếp hạng" />
              <NavItem to="/settings" icon="⚙️" label="Cài đặt" />
            </div>

            <div className="mt-auto pt-8">
              <div className="bg-natural-beige p-4 rounded-2xl text-center">
                <span className="text-3xl font-black text-natural-sage block leading-none mb-1">
                  {Math.floor(userProgress.xp / 1000) + 1}
                </span>
                <span className="text-[11px] uppercase font-bold text-natural-muted tracking-wide">
                  Level hiện tại
                </span>
              </div>
            </div>
          </aside>

          {/* Content Center */}
          <main className="bg-natural-card overflow-y-auto relative">
            <AnimatePresence mode="wait">
              <Routes>
                <Route path="/" element={<HomeScreen progress={userProgress} />} />
                <Route path="/lesson/:id" element={<LessonScreen progress={userProgress} setProgress={setUserProgress} />} />
                <Route path="/ai-chat" element={<AIChatScreen />} />
                <Route path="/flashcards" element={<FlashcardsScreen />} />
                <Route path="/profile" element={<ProfileScreen progress={userProgress} />} />
                <Route path="*" element={<Navigate to="/" replace />} />
              </Routes>
            </AnimatePresence>
          </main>

          {/* Sidebar Right */}
          <aside className="bg-white p-8 flex flex-col h-full overflow-y-auto">
            <div className="bg-natural-ai rounded-[20px] p-5 text-white mb-8">
              <h3 className="text-lg font-bold mb-2">Gia sư AI 🤖</h3>
              <p className="text-sm opacity-80 mb-4 leading-relaxed">
                Luyện tập hội thoại tiếng Hàn thực tế với AI Teacher. Sửa lỗi ngay lập tức!
              </p>
              <a 
                href="/ai-chat"
                className="block w-full py-2.5 rounded-xl bg-white/20 text-center font-semibold hover:bg-white/30 transition-all"
              >
                Bắt đầu Chat
              </a>
            </div>

            <div className="section-title">Nhiệm vụ hàng ngày</div>
            <div className="space-y-4 mb-10">
              <QuestItem icon="🎯" label="Học 15 từ mới" progress={60} />
              <QuestItem icon="🔥" label="Hoàn thành 2 bài học" progress={100} />
            </div>

            <div className="section-title">Ôn tập SRS</div>
            <a 
              href="/flashcards"
              className="flex items-center gap-3 p-4 bg-[#F1F4E8] border border-dashed border-natural-sage rounded-xl text-natural-sage font-bold"
            >
              <span>🧠</span> 12 từ cần ôn tập
            </a>
          </aside>
        </div>
      </div>
    </Router>
  );
}

function NavItem({ to, icon, label }: { to: string; icon: string; label: string }) {
  const isActive = window.location.pathname === to;
  return (
    <a
      href={to}
      className={cn(
        "flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 font-bold",
        isActive ? "bg-natural-beige text-natural-sage" : "text-natural-ink hover:bg-[#FAF7F2]"
      )}
    >
      <span className="text-xl">{icon}</span>
      <span className="text-sm">{label}</span>
    </a>
  );
}

function QuestItem({ icon, label, progress }: { icon: string; label: string; progress: number }) {
  return (
    <div className="flex items-center gap-3">
      <div className="text-xl">{icon}</div>
      <div className="flex-1">
        <div className="text-sm font-bold mb-1">{label}</div>
        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
          <div 
            className="h-full bg-natural-sage transition-all duration-500" 
            style={{ width: `${progress}%` }} 
          />
        </div>
      </div>
    </div>
  );
}

